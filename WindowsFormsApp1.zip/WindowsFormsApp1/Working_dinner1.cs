﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class Working_dinner1 : Form
    {
        public Working_dinner1()
        {
            InitializeComponent();
        }

        private void Working_dinner1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select first_name,last_name from workers where employ_number ='" + EMPLOYNUMBERMEALBOX.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                string first_name = dt.Rows[0]["first_name"].ToString();
                string last_name = dt.Rows[0]["last_name"].ToString();
                SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
                DataTable dt4 = new DataTable();
                sqaa.Fill(dt4);
                string totalamout = dt4.Rows[0][0].ToString();
                SqlDataAdapter asd = new SqlDataAdapter("INSERT INTO workermeal (employee_number,first_name,last_name,meal_cost,date) VALUES('"+EMPLOYNUMBERMEALBOX.Text+"','"+first_name+"','"+last_name+"','"+totalamout+"',getdate())", con);
                asd.SelectCommand.ExecuteNonQuery();
                SqlDataAdapter aqd1= new SqlDataAdapter("DELETE FROM TemporyRecipe ", con);
                aqd1.SelectCommand.ExecuteNonQuery();
                MessageBox.Show("bon appetit!");
                this.Hide();
            }
            else
            {
                MessageBox.Show("Employee is not on the List");
            }
        }
    }
}
