﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1.userControls
{
    public partial class update_customer_phone1 : Form
    {
        public update_customer_phone1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from customers where id ='" + updatephoneidbox.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                SqlDataAdapter sda = new SqlDataAdapter("UPDATE customers SET phone='" + updtaephonebox.Text + "'WHERE id='" + updatephoneidbox.Text + "'", con);
                sda.SelectCommand.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("update");
                this.Dispose();
            }
            else
            {
                MessageBox.Show("The Customer is not on the List");
            }
        }
    }
}
