﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1.userControls
{
    public partial class UC_reports : UserControl
    {
        public UC_reports()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            premissions_login premission = new premissions_login();
            premission.ShowDialog();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from premission_login where premission=1", con);
            con.Close();
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                con.Open();
                SqlDataAdapter aSd = new SqlDataAdapter("DELETE FROM premission_login", con);
                aSd.SelectCommand.ExecuteNonQuery();
                con.Close();
                employeehoursreport hoursreport = new employeehoursreport();
                hoursreport.Show();

            }
            else
            {
                MessageBox.Show("no premission");
            }
            con.Open();
            SqlDataAdapter ald = new SqlDataAdapter("DELETE FROM premission_login", con);
            ald.SelectCommand.ExecuteNonQuery();
            con.Close();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            premissions_login premission = new premissions_login();
            premission.ShowDialog();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from premission_login where premission=1 or premission=2", con);
            con.Close();
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                con.Open();
                SqlDataAdapter aSd = new SqlDataAdapter("DELETE FROM premission_login", con);
                aSd.SelectCommand.ExecuteNonQuery();
                con.Close();
                DailyReport daily = new DailyReport();
                daily.Show();
            }
            else
            {
                MessageBox.Show("no premission");
            }
            con.Open();
            SqlDataAdapter ald = new SqlDataAdapter("DELETE FROM premission_login", con);
            ald.SelectCommand.ExecuteNonQuery();
            con.Close();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            premissions_login premission = new premissions_login();
            premission.ShowDialog();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from premission_login where premission=1 or premission=2", con);
            con.Close();
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                con.Open();
                SqlDataAdapter aSd = new SqlDataAdapter("DELETE FROM premission_login", con);
                aSd.SelectCommand.ExecuteNonQuery();
                con.Close();
                monthlyreport report = new monthlyreport();
                report.Show();

            }
            else
            {
                MessageBox.Show("no premission");
            }
            con.Open();
            SqlDataAdapter ald = new SqlDataAdapter("DELETE FROM premission_login", con);
            ald.SelectCommand.ExecuteNonQuery();
            con.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            recipetsreport recipet = new recipetsreport();
            recipet.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
                        
        }
    }
}
