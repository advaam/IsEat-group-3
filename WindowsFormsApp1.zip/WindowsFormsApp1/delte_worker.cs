﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1.userControls
{
    public partial class delte_worker : Form
    {
        public delte_worker()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Delete the emoployee (through the BL class)
            bool status = WindowsFormsApp1.Buisness_Logic.DeleteWorkerBL.DeleteWorker(deleteworkeridbox.Text);

            // Check the status boolean status

           
            if (status == true)
            {
                MessageBox.Show("removed");
                this.Hide();
            }
            else
            {
                MessageBox.Show("The Worker is not on The List");
            }
        }
    }
}
