﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1.userControls
{
    public partial class CLOCK_ENTER : Form
    {
        public CLOCK_ENTER()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from workers where id ='" + ENTERCLOCKIDBOX.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                aqd = new SqlDataAdapter("select * from workers_hours where id='"+ENTERCLOCKIDBOX.Text+"'and enter is not null and exit_time is null", con);
                DataTable rs = new DataTable();
                aqd.Fill(rs);
                if(rs.Rows.Count==1)
                {
                    MessageBox.Show("the employee already enter the clock");
                }
                else
                {
                    SqlDataAdapter sda = new SqlDataAdapter("INSERT INTO workers_hours (id,enter) VALUES('" + ENTERCLOCKIDBOX.Text + "',getdate())", con);
                    sda.SelectCommand.ExecuteNonQuery();
                    MessageBox.Show("in!");
                    this.Hide();
                }
                
            }
            else
            {
                MessageBox.Show("id is not on the list");
            }
        }
    }
}
