﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class CalculatingAverageInovice : Form
    {
        public CalculatingAverageInovice()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaaa = new SqlDataAdapter("SELECT * FROM Total_inovice where employee_number='" + employeenumberbox.Text + "'", con);
            DataTable dt5 = new DataTable();
            sqaaa.Fill(dt5);
            if(dt5.Rows.Count>=1)
            {
                SqlDataAdapter sqa= new SqlDataAdapter("SELECT first_name,last_name,premission FROM workers where employ_number='" + employeenumberbox.Text + "'", con);
                DataTable dt = new DataTable();
                sqa.Fill(dt);
                string firstname = dt.Rows[0]["first_name"].ToString();
                string lastname = dt.Rows[0]["last_name"].ToString();
                string premission = dt.Rows[0]["premission"].ToString();
                sqa = new SqlDataAdapter("SELECT sum(price) FROM Total_inovice where employee_number='"+employeenumberbox.Text+"'", con);
                dt = new DataTable();
                sqa.Fill(dt);
                int totalamount = Int32.Parse(dt.Rows[0][0].ToString());
                sqa = new SqlDataAdapter("SELECT * FROM Total_inovice where employee_number='" + employeenumberbox.Text + "'", con);
                dt = new DataTable();
                sqa.Fill(dt);
                int count = dt.Rows.Count;
                totalamount = totalamount / count;
                sqa = new SqlDataAdapter("INSERT INTO inoviceavarage(first_name,last_name,premission,employee_number,inovice_avarage) VALUES('"+firstname+"','"+lastname+"','"+premission+"','"+employeenumberbox.Text+"','"+totalamount+"')", con);
                sqa.SelectCommand.ExecuteNonQuery();
                sqa = new SqlDataAdapter("SELECT * FROM inoviceavarage", con);
                dt = new DataTable();
                sqa.Fill(dt);
                dataGridView1.DataSource = dt;
                sqa = new SqlDataAdapter("DELETE FROM inoviceavarage", con);
                sqa.SelectCommand.ExecuteNonQuery();
                con.Close();


            }
            else
            {
                MessageBox.Show("Employee is not on the List Or dont have Sales");
            }
        }

        private void CalculatingAverageInovice_Load(object sender, EventArgs e)
        {

        }
    }
}
