﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class opendayform : Form
    {
        public opendayform()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            // Update the user permission (through the BL class)
            bool status = WindowsFormsApp1.Buisness_Logic.OpenDayBL.OpenDayPermission(employnumberbox.Text, initialamountbox.Text);

            // Check the status boolean status


            if (status == true)
            {
                MessageBox.Show("Opend!");
                this.Hide();
            }
            else
            {
                MessageBox.Show("Employ is not on the List");
            }
        }
    }
}
