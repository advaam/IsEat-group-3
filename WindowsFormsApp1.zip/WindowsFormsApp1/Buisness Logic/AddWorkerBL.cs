﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Data;

namespace WindowsFormsApp1.Buisness_Logic
{
    public static class AddWorkerBL
    {
        public static bool AddNewWorker(string ID, string firstName, string lastName, string employeeNumber, string premission)
        {
            //Init 
            bool status;

            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from workers where id ='" + ID + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)// If the employee is allredy on the list return false
            {
                status = false;
            }
            else // Add a new employee
            {
                SqlDataAdapter sda = new SqlDataAdapter("INSERT INTO workers (id,first_name,last_name,employ_number,start_date,premission) VALUES('" + ID + "','" + firstName + "','" + lastName + "','" + employeeNumber + "',getdate(),'" + premission + "')", con);
                sda.SelectCommand.ExecuteNonQuery();
                con.Close();
                
                // Update Bool status
                status = true;
            }
            // Ret
            return status;
        }
    }
}
