﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Data;

namespace WindowsFormsApp1.Buisness_Logic
{
    public static class LoginBL
    {
        public static bool login(string userName) {
            bool status;

            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from login where password ='" + userName + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)// If the user is on the list, login
            {
                status = true;
            }
            else// If the user is not on the list display an error massege
            {
                status = false;
            }

            return status;
        }
    }
}
