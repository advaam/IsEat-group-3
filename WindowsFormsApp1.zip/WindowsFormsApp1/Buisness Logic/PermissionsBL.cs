﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Data;

namespace WindowsFormsApp1.Buisness_Logic
{
    public static class PermissionsBL
    {
        public static bool UpdatePermission(string userID, string permissionID)
        {
            // Init
            bool status;

            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from workers where id ='" + userID + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                SqlDataAdapter sda = new SqlDataAdapter("UPDATE workers SET premission='" + permissionID + "'WHERE id='" + userID + "'", con);
                sda.SelectCommand.ExecuteNonQuery();
                con.Close();

                // Update Bool status
                status = true;
            }
            else
            {
                // Update status
                status = false;
            }

            // Ret
            return status;
        }
    }
}
