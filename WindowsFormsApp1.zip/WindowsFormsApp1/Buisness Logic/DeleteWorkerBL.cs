﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Data;


namespace WindowsFormsApp1.Buisness_Logic
{
   public static class DeleteWorkerBL
    {
        public static bool DeleteWorker(string employeeID)
        {
            //Init 
            bool status;

            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from workers where id ='" + employeeID + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1) //If the employee is on the list, delete him
            {
                SqlDataAdapter sqa = new SqlDataAdapter("DELETE FROM workers WHERE id='" + employeeID + "'", con);
                sqa.SelectCommand.ExecuteNonQuery();
                con.Close();

                // Update Bool status
                status = true;
            }
            else
            {
                // Update Bool status
                status = false;
            }
            // Ret
            return status;
        }
    }
}
