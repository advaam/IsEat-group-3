﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.ComponentModel;
using System.Data;

namespace WindowsFormsApp1.Buisness_Logic
{
    public static class OpenDayBL
    {
        public static bool OpenDayPermission(string employeeNumber, string initialAmount)
        {
            //Init 
            bool status;

            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaaa = new SqlDataAdapter("SELECT * FROM workers where employ_number='" + employeeNumber + "'", con);
            DataTable dt5 = new DataTable();
            sqaaa.Fill(dt5);
            if (dt5.Rows.Count == 1)// If the number is on the list, open a new day
            {
                SqlDataAdapter sqa = new SqlDataAdapter("INSERT INTO Openday (day_date,employe_number,initial_amount) VALUES(getdate(),'" + employeeNumber + "','" + initialAmount + "')", con);
                sqa.SelectCommand.ExecuteNonQuery();
                
                // Update Bool status
                status = true;
            }
            else// If the number is not on the list display an error massege
            {
                // Update Bool status
                status = false;
            }

            // Ret
            return status;
        }
    }
}
