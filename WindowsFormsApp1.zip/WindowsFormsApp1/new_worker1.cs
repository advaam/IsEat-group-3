﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1.userControls
{
    public partial class new_worker1 : Form
    {
        public new_worker1()
        {
            InitializeComponent();
            comboBox1.Items.Add("1");
            comboBox1.Items.Add("2");
            comboBox1.Items.Add("3");

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Add employee info (through the BL class)
            bool status = WindowsFormsApp1.Buisness_Logic.AddWorkerBL.AddNewWorker(IdNewWorkerBox.Text, firstnameworkerbox.Text, lastnameworkerbox.Text, employeenumberworkerbox.Text, comboBox1.SelectedItem.ToString());
            

            // Check the status boolean status
            if (status == false)
            {
                MessageBox.Show("The Worker is Already on the List");
            }
            else
            {
                MessageBox.Show("add");
                this.Dispose();
            }
            
        }

        private void new_worker1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
