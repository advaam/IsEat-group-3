﻿namespace WindowsFormsApp1.userControls
{
    partial class adding_customer1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.PHONENUMBERCUSTOMERBOX = new System.Windows.Forms.TextBox();
            this.LASTNAMECUSTOMERBOX = new System.Windows.Forms.TextBox();
            this.FIRSTNAMECUSTOMERBOX = new System.Windows.Forms.TextBox();
            this.IDCUSTOMERBOX = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // PHONENUMBERCUSTOMERBOX
            // 
            this.PHONENUMBERCUSTOMERBOX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.PHONENUMBERCUSTOMERBOX.Location = new System.Drawing.Point(383, 275);
            this.PHONENUMBERCUSTOMERBOX.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.PHONENUMBERCUSTOMERBOX.Name = "PHONENUMBERCUSTOMERBOX";
            this.PHONENUMBERCUSTOMERBOX.Size = new System.Drawing.Size(161, 23);
            this.PHONENUMBERCUSTOMERBOX.TabIndex = 10;
            // 
            // LASTNAMECUSTOMERBOX
            // 
            this.LASTNAMECUSTOMERBOX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.LASTNAMECUSTOMERBOX.Location = new System.Drawing.Point(383, 228);
            this.LASTNAMECUSTOMERBOX.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.LASTNAMECUSTOMERBOX.Name = "LASTNAMECUSTOMERBOX";
            this.LASTNAMECUSTOMERBOX.Size = new System.Drawing.Size(161, 23);
            this.LASTNAMECUSTOMERBOX.TabIndex = 11;
            // 
            // FIRSTNAMECUSTOMERBOX
            // 
            this.FIRSTNAMECUSTOMERBOX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.FIRSTNAMECUSTOMERBOX.Location = new System.Drawing.Point(383, 182);
            this.FIRSTNAMECUSTOMERBOX.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.FIRSTNAMECUSTOMERBOX.Name = "FIRSTNAMECUSTOMERBOX";
            this.FIRSTNAMECUSTOMERBOX.Size = new System.Drawing.Size(161, 23);
            this.FIRSTNAMECUSTOMERBOX.TabIndex = 12;
            // 
            // IDCUSTOMERBOX
            // 
            this.IDCUSTOMERBOX.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.IDCUSTOMERBOX.Location = new System.Drawing.Point(383, 141);
            this.IDCUSTOMERBOX.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.IDCUSTOMERBOX.Name = "IDCUSTOMERBOX";
            this.IDCUSTOMERBOX.Size = new System.Drawing.Size(161, 23);
            this.IDCUSTOMERBOX.TabIndex = 13;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold);
            this.button1.Location = new System.Drawing.Point(254, 369);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(200, 36);
            this.button1.TabIndex = 9;
            this.button1.Text = "confirm";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(104, 269);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(190, 28);
            this.label5.TabIndex = 4;
            this.label5.Text = "phone number:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(160, 228);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(134, 28);
            this.label4.TabIndex = 5;
            this.label4.Text = "last name:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(161, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 28);
            this.label3.TabIndex = 6;
            this.label3.Text = "first name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(252, 141);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 28);
            this.label2.TabIndex = 7;
            this.label2.Text = "Id:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(165, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(460, 47);
            this.label1.TabIndex = 8;
            this.label1.Text = "Adding New Customre";
            // 
            // adding_customer1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(736, 451);
            this.Controls.Add(this.PHONENUMBERCUSTOMERBOX);
            this.Controls.Add(this.LASTNAMECUSTOMERBOX);
            this.Controls.Add(this.FIRSTNAMECUSTOMERBOX);
            this.Controls.Add(this.IDCUSTOMERBOX);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "adding_customer1";
            this.Text = "adding_customer1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox PHONENUMBERCUSTOMERBOX;
        private System.Windows.Forms.TextBox LASTNAMECUSTOMERBOX;
        private System.Windows.Forms.TextBox FIRSTNAMECUSTOMERBOX;
        private System.Windows.Forms.TextBox IDCUSTOMERBOX;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}