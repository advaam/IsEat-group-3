﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class CloseDayForm : Form
    {
        public CloseDayForm()
        {
            InitializeComponent();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM Dailyinovice", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            if (dt4.Rows.Count >= 1)
            {
                string totalamout = dt4.Rows[0][0].ToString();
                Totalamountlabel.Text = totalamout;
            }
            con.Close();
            this.Width = 732;
            this.Height = 433;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            calculator calc = new calculator();
            calc.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT * FROM workers where employ_number='"+employnumberbox.Text+"'", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            if (dt4.Rows.Count == 1)// If the employee is on the list
            {
                SqlDataAdapter sqa = new SqlDataAdapter("SELECT sum(price) FROM Dailyinovice ", con);
                DataTable dt = new DataTable();
                sqa.Fill(dt);
                string total = "0";
                
                if (dt.Rows.Count != 0)
                {
                    
                    total = dt.Rows[0][0].ToString();
                    
                }
                
                SqlDataAdapter sqaaa = new SqlDataAdapter("SELECT sum(price) FROM DailyInovice where payment_type='cash'", con);
                DataTable dt1 = new DataTable();
                sqaaa.Fill(dt1);
                string cash_total = "0";
                
                if (dt1.Rows.Count != 0)
                {
                    cash_total = dt1.Rows[0][0].ToString();
                }
                
                SqlDataAdapter sqaaa1 = new SqlDataAdapter("SELECT sum(price) FROM DailyInovice where payment_type='credit'", con);
                DataTable dt11 = new DataTable();
                sqaaa1.Fill(dt11);
                string credit_total1 = "0";
                if (dt11.Rows.Count != 0)
                {
                    
                    credit_total1 = dt11.Rows[0][0].ToString();
                    
                }
                sqa = new SqlDataAdapter("INSERT INTO CloseDay(day_date,employee_number,total_amount,cash_total,credit_total) VALUES(getdate(),'" + employnumberbox.Text + "','" + total + "','"+ cash_total + "','"+ credit_total1 + "')", con);
                sqa.SelectCommand.ExecuteNonQuery();
                sqa = new SqlDataAdapter("DELETE FROM Dailyinovice", con);
                sqa.SelectCommand.ExecuteNonQuery();
                MessageBox.Show("Closed!");
                con.Close();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Employee is not on the List");
            }
            
        }

        private void CloseDayForm_Load(object sender, EventArgs e)
        {

        }

        private void employnumberbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
