﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1.userControls
{
    public partial class update_premission : Form
    {
        public update_premission()
        {
            InitializeComponent();
            comboBox1.Items.Add("1");
            comboBox1.Items.Add("2");
            comboBox1.Items.Add("3");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Update the user permission (through the BL class)
            bool status = WindowsFormsApp1.Buisness_Logic.PermissionsBL.UpdatePermission(updatepremissionidbox.Text, comboBox1.SelectedItem.ToString());
            
            // Check the status boolean status
            if (status == true)
            {
                MessageBox.Show("update");
                this.Dispose();
            }
            else
            {
                MessageBox.Show("The Worker is not on the List");
            }
        }
    }
}
