﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1.userControls
{
    public partial class money_box_managemnt_change_product_price : Form
    {
        public money_box_managemnt_change_product_price()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from money_box_managment where productName ='" + moneyboxmanagemntchangeproductnamebox.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                SqlDataAdapter sda = new SqlDataAdapter("UPDATE money_box_managment SET cost='" + moneyboxmanagemntchangeproductcostbox.Text + "'WHERE productName='" + moneyboxmanagemntchangeproductnamebox.Text + "'", con);
                sda.SelectCommand.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("update");
                this.Dispose();
            }
            else
            {
                MessageBox.Show("The product is not on the money box product");
            }
        }
    }
}
