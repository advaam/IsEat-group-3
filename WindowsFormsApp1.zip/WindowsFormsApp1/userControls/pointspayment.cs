﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1.userControls
{
    public partial class pointspayment : Form
    {
        public pointspayment()
        {
            InitializeComponent();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            if (dt4.Rows.Count >= 1)
            {
                string totalamout = dt4.Rows[0][0].ToString();
                label4.Text = totalamout;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT * FROM customers where id='"+customeridbox.Text+"'", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            if(dt4.Rows.Count==1)//if customer is on the list
            {
                sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
                dt4 = new DataTable();
                sqaa.Fill(dt4);
                int total = Int32.Parse(dt4.Rows[0][0].ToString());
                sqaa = new SqlDataAdapter("SELECT points FROM customers where id='" + customeridbox.Text + "'", con);
                dt4 = new DataTable();
                sqaa.Fill(dt4);
                int pointsofcustomer = Int32.Parse(dt4.Rows[0][0].ToString());
                int pointsthatenter = Int32.Parse(numberofpointsbox.Text);
                if (pointsthatenter>total)
                {
                    MessageBox.Show("Points that insert is bigger then the Total Price");
                }
                else//if the points that insert is not bigger then the total price
                {
                    if(pointsthatenter>pointsofcustomer)
                    {
                        MessageBox.Show("Points that Insert is bigger then Points of the Customer");
                    }
                    else
                    {
                        int totalforsql = total;
                        total = total - pointsthatenter;
                        pointsofcustomer = pointsofcustomer - pointsthatenter;
                        if(total==0)
                        {
                            SqlDataAdapter sqa = new SqlDataAdapter("INSERT INTO Dailyinovice (date,price,payment_type) VALUES (getdate(),'" + totalforsql + "','points')", con);
                            sqa.SelectCommand.ExecuteNonQuery();
                            SqlDataAdapter sqa1 = new SqlDataAdapter("INSERT INTO Total_inovice (date,price,payment_type) VALUES(getdate(),'" + totalforsql + "','points')", con);
                            sqa1.SelectCommand.ExecuteNonQuery();
                            SqlDataAdapter aqd = new SqlDataAdapter("DELETE FROM TemporyRecipe", con);
                            aqd.SelectCommand.ExecuteNonQuery();
                            SqlDataAdapter sda = new SqlDataAdapter("UPDATE customers SET points='" + pointsofcustomer + "' WHERE id='" + customeridbox.Text + "'", con);
                            sda.SelectCommand.ExecuteNonQuery();
                            MessageBox.Show("Payed");
                            this.Hide();
                        }
                        else
                        {
                            pointsthatenter = pointsthatenter * -1;
                            SqlDataAdapter aqd = new SqlDataAdapter("INSERT INTO TemporyRecipe (product,quantity,price) VALUES('points',1,'" + pointsthatenter +"')", con);
                            aqd.SelectCommand.ExecuteNonQuery();
                            SqlDataAdapter sda = new SqlDataAdapter("UPDATE customers SET points='" + pointsofcustomer + "' WHERE id='" + customeridbox.Text + "'", con);
                            sda.SelectCommand.ExecuteNonQuery();
                            MessageBox.Show("Payed");
                            this.Hide();
                            MessageBox.Show("Not All Inovice is Payed");
                        }
                    }
                }

            }
            else
            {
                MessageBox.Show("Customer is not on the List");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
