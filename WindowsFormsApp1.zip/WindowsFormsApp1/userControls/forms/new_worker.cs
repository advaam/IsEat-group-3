﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1.userControls.forms
{
    public partial class new_worker : Form
    {
        public new_worker()
        {
            InitializeComponent();
        }
    }
}
