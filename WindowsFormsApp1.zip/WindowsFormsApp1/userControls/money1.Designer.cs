﻿namespace WindowsFormsApp1.userControls
{
    partial class money1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calaculatepaymentbox = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.changelabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.employnumberpaymentcashbox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.customeridcashpaymentbox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // calaculatepaymentbox
            // 
            this.calaculatepaymentbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.calaculatepaymentbox.Location = new System.Drawing.Point(348, 140);
            this.calaculatepaymentbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.calaculatepaymentbox.Name = "calaculatepaymentbox";
            this.calaculatepaymentbox.Size = new System.Drawing.Size(109, 33);
            this.calaculatepaymentbox.TabIndex = 9;
            this.calaculatepaymentbox.Text = "calculate";
            this.calaculatepaymentbox.UseVisualStyleBackColor = true;
            this.calaculatepaymentbox.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(177)));
            this.button1.Location = new System.Drawing.Point(310, 313);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 36);
            this.button1.TabIndex = 10;
            this.button1.Text = "confirm";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(310, 99);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(147, 22);
            this.textBox1.TabIndex = 8;
            // 
            // changelabel
            // 
            this.changelabel.AutoSize = true;
            this.changelabel.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.changelabel.ForeColor = System.Drawing.Color.Red;
            this.changelabel.Location = new System.Drawing.Point(297, 141);
            this.changelabel.Name = "changelabel";
            this.changelabel.Size = new System.Drawing.Size(45, 32);
            this.changelabel.TabIndex = 3;
            this.changelabel.Text = "00";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(161, 141);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 32);
            this.label4.TabIndex = 4;
            this.label4.Text = "Change:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(204, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 32);
            this.label3.TabIndex = 5;
            this.label3.Text = "cash:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(377, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(64, 47);
            this.label2.TabIndex = 6;
            this.label2.Text = "00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 24F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(22, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(303, 47);
            this.label1.TabIndex = 7;
            this.label1.Text = "total payment:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(24, 191);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(266, 32);
            this.label6.TabIndex = 5;
            this.label6.Text = "Employee Number:";
            // 
            // employnumberpaymentcashbox
            // 
            this.employnumberpaymentcashbox.Location = new System.Drawing.Point(310, 201);
            this.employnumberpaymentcashbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.employnumberpaymentcashbox.Name = "employnumberpaymentcashbox";
            this.employnumberpaymentcashbox.Size = new System.Drawing.Size(147, 22);
            this.employnumberpaymentcashbox.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 16F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(110, 241);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(180, 32);
            this.label7.TabIndex = 5;
            this.label7.Text = "Customer id:";
            // 
            // customeridcashpaymentbox
            // 
            this.customeridcashpaymentbox.Location = new System.Drawing.Point(310, 241);
            this.customeridcashpaymentbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.customeridcashpaymentbox.Name = "customeridcashpaymentbox";
            this.customeridcashpaymentbox.Size = new System.Drawing.Size(147, 22);
            this.customeridcashpaymentbox.TabIndex = 8;
            // 
            // money1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(553, 451);
            this.Controls.Add(this.calaculatepaymentbox);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.customeridcashpaymentbox);
            this.Controls.Add(this.employnumberpaymentcashbox);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.changelabel);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "money1";
            this.Text = "money1";
            this.Load += new System.EventHandler(this.money1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button calaculatepaymentbox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label changelabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox employnumberpaymentcashbox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox customeridcashpaymentbox;
    }
}