﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1.userControls
{
    public partial class payments1 : Form
    {
        public payments1()
        {
            InitializeComponent();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            money1 cash = new money1();
            
            cash.ShowDialog();
            this.Hide();
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            premissions_login premission = new premissions_login();
            premission.ShowDialog();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from premission_login where premission=1 or premission=2", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                SqlDataAdapter aSd = new SqlDataAdapter("DELETE FROM premission_login", con);
                aSd.SelectCommand.ExecuteNonQuery();
                cacncelittion dsgsdf = new cacncelittion();
                dsgsdf.ShowDialog();
                this.Hide();

            }
            else
            {
                MessageBox.Show("no premission");
            }
            SqlDataAdapter aLd = new SqlDataAdapter("DELETE premission_login", con);
            aLd.SelectCommand.ExecuteNonQuery();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Working_dinner1 dinner = new Working_dinner1();
            dinner.ShowDialog();
            this.Hide();
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            credit_payment credit = new credit_payment();
            
            credit.ShowDialog();
            this.Hide();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            pointspayment points = new pointspayment();
            points.ShowDialog();
            this.Hide();
        }
    }
}
