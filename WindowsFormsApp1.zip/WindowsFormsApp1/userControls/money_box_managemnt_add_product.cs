﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1.userControls
{
    public partial class money_box_managemnt_add_product : Form
    {
        public money_box_managemnt_add_product()
        {
            InitializeComponent();
        }

        private void money_box_managemnt_add_product_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from money_box_managment where productName ='" + moneyboxmanagemntaddproductnamebox.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                MessageBox.Show("product is already on money box product");
            }
            else
            {
                SqlDataAdapter sda = new SqlDataAdapter("INSERT INTO money_box_managment (productName,cost) VALUES('" + moneyboxmanagemntaddproductnamebox.Text + "','" + moneyboxmanagemntaddproductcostbox.Text + "')", con);
                sda.SelectCommand.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("add");
                this.Dispose();
            }
        }
    }
}
