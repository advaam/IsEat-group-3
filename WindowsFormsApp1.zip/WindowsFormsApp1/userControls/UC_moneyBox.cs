﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Data.SqlClient;
namespace WindowsFormsApp1.userControls
{
    public partial class UC_moneyBox : UserControl
    {

        public UC_moneyBox()
        {
            InitializeComponent();
            Button temp;
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter s = new SqlDataAdapter("select * from TemporyRecipe", con);
            DataTable xi = new DataTable();
            s.Fill(xi);
            recipregridview.DataSource = xi;
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            if (dt4.Rows.Count >= 1)
            {
                string totalamout = dt4.Rows[0][0].ToString();
                label3.Text = totalamout;
            }
            SqlDataAdapter aqd = new SqlDataAdapter("select * from money_box_managment", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            int x = dt.Rows.Count;
            for (int i = 0; i < x; i++)
            {
                string buttonnames = dt.Rows[i]["productName"].ToString();
                int price =Int32.Parse(dt.Rows[i]["cost"].ToString());
                temp = new Button();
                temp.ForeColor = Color.White;
                temp.BackColor = Color.IndianRed;
                temp.FlatStyle = FlatStyle.Flat;
                temp.Width = 120;
                temp.Height = 100;
                temp.Name = "flaver" + i+1;
                temp.Text = buttonnames;
                temp.Click += new EventHandler(this.addItem);
                this.flowLayoutPanel1.Controls.Add(temp);
            }
        }

        private void addItem(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            string thebuttonname = btn.Text.ToString();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from money_box_managment where productName='" + thebuttonname + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            SqlDataAdapter asd = new SqlDataAdapter("select * from TemporyRecipe where Product='" + thebuttonname + "'", con);
            DataTable dt1 = new DataTable();
            asd.Fill(dt1);
            int newprice = Int32.Parse(dt.Rows[0]["cost"].ToString());
            if (dt1.Rows.Count==1)
            {
                
                newprice = newprice+Int32.Parse(dt1.Rows[0]["price"].ToString());
                int newquantity = Int32.Parse(dt1.Rows[0]["quantity"].ToString())+1;
                SqlDataAdapter sda = new SqlDataAdapter("UPDATE TemporyRecipe SET quantity='" + newquantity + "',price='" + newprice + "' WHERE Product='"+thebuttonname+"'", con);
                sda.SelectCommand.ExecuteNonQuery();
                
            }
            else
            {
                
                SqlDataAdapter sda = new SqlDataAdapter("INSERT INTO TemporyRecipe(Product,quantity,price) VALUES('" + thebuttonname + "',1,'" + newprice + "')", con);
                sda.SelectCommand.ExecuteNonQuery();
                
            }
           
            SqlDataAdapter sqa1 = new SqlDataAdapter("SELECT * FROM TemporyRecipe", con);
            DataTable dt3 = new DataTable();
            sqa1.Fill(dt3);
            recipregridview.DataSource = dt3.DefaultView;
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            if (dt4.Rows.Count >= 1)
            {
                string totalamout = dt4.Rows[0][0].ToString();
                label3.Text = totalamout;
            }
            con.Close();
        }
        private void UC_moneyBox_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            int x=recipregridview.CurrentCell.RowIndex;
            string product = recipregridview.Rows[x].Cells[0].Value.ToString();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("DELETE FROM TemporyRecipe WHERE Product='" + product+ "'", con);
            aqd.SelectCommand.ExecuteNonQuery();
            SqlDataAdapter sqa1 = new SqlDataAdapter("SELECT * FROM TemporyRecipe", con);
            DataTable dt3 = new DataTable();
            sqa1.Fill(dt3);
            recipregridview.DataSource = dt3.DefaultView;
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            if (dt4.Rows.Count >= 1)
            {
                string totalamout = dt4.Rows[0][0].ToString();
                label3.Text = totalamout;
            }
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
          
        }

        private void panel8_Paint(object sender, PaintEventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void recipregridview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("DELETE FROM TemporyRecipe", con);
            aqd.SelectCommand.ExecuteNonQuery();
            SqlDataAdapter sqa1 = new SqlDataAdapter("SELECT * FROM TemporyRecipe", con);
            DataTable dt3 = new DataTable();
            sqa1.Fill(dt3);
            recipregridview.DataSource = dt3.DefaultView;
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            if (dt4.Rows.Count >= 1)
            {
                string totalamout = dt4.Rows[0][0].ToString();
                label3.Text = totalamout;
            }
            con.Close();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqa = new SqlDataAdapter("SELECT * FROM TemporyRecipe", con);
            DataTable dt3 = new DataTable();
            sqa.Fill(dt3);
            if(dt3.Rows.Count!=0)
            {
                payments1 payment = new payments1();
                payment.ShowDialog();
                sqa = new SqlDataAdapter("SELECT * FROM TemporyRecipe", con);
                dt3 = new DataTable();
                sqa.Fill(dt3);
                recipregridview.DataSource = dt3;
                SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
                DataTable dt4 = new DataTable();
                sqaa.Fill(dt4);
                if(dt4.Rows.Count==1)
                {
                    string totalamount = dt4.Rows[0][0].ToString();
                    label3.Text = totalamount;
                }
                else
                {
                    label3.Text = "00";
                }
                
            }
            else
            {
                MessageBox.Show("Inovice is Empty");
            }
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
