﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1.userControls
{
    public partial class UC_cashmanagment : UserControl
    {
        public UC_cashmanagment()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            money_box_managemnt_add_product product = new money_box_managemnt_add_product();
            product.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            money_box_managemnt_delete_product product = new money_box_managemnt_delete_product();
            product.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            money_box_managemnt_change_product_price product = new money_box_managemnt_change_product_price();
            product.Show();
        }
    }
}
