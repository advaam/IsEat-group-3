﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class cacncelittion : Form
    {
        public cacncelittion()
        {
            InitializeComponent();
            comboBox1.Items.Add("cash");
            comboBox1.Items.Add("credit");
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            totalamountlabel.Text = dt4.Rows[0][0].ToString();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            totalamountlabel.Text = dt4.Rows[0][0].ToString();
            int decrease = Int32.Parse(dt4.Rows[0][0].ToString());
            decrease = decrease * -1;
            SqlDataAdapter sqa = new SqlDataAdapter("INSERT INTO Dailyinovice (date,price,payment_type) VALUES (getdate(),'" + decrease + "','"+comboBox1.SelectedItem.ToString()+"')", con);
            sqa.SelectCommand.ExecuteNonQuery();
            SqlDataAdapter sqa1 = new SqlDataAdapter("INSERT INTO Total_inovice (date,price,payment_type) VALUES(getdate(),'" + decrease + "','"+ comboBox1.SelectedItem.ToString() + "')", con);
            sqa1.SelectCommand.ExecuteNonQuery();
            MessageBox.Show("cancel");
            SqlDataAdapter aSd = new SqlDataAdapter("DELETE FROM TemporyRecipe", con);
            aSd.SelectCommand.ExecuteNonQuery();
            con.Close();
            this.Hide();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
