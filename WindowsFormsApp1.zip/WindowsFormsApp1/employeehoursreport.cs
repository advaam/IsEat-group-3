﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class employeehoursreport : Form
    {
        public employeehoursreport()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter asd = new SqlDataAdapter("SELECT id FROM workers_hours WHERE id='"+employeenumberbox.Text+"'", con);
            DataTable dt1 = new DataTable();
            asd.Fill(dt1);
            if(dt1.Rows.Count>=1)
            {
                SqlDataAdapter aqd = new SqlDataAdapter("SELECT SUM(DATEDIFF(second,enter,exit_time))/3600 as [Total Hours] FROM workers_hours WHERE id='" + employeenumberbox.Text + "'AND CAST(enter AS DATE) BETWEEN '" + startingdatetimer.Value.ToString("yyyy-MM-dd") + "' AND '" + finishdatetimer.Value.ToString("yyyy-MM-dd") + "' AND CAST(exit_time AS DATE) BETWEEN '" + startingdatetimer.Value.ToString("yyyy-MM-dd") + "' AND '" + finishdatetimer.Value.ToString("yyyy-MM-dd") + "'", con);
                DataTable dt = new DataTable();
                aqd.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else
            {
                MessageBox.Show("Employee is not on the List");
            }
            
        }
    }
}
