﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class DailyReport : Form
    {
        public DailyReport()
        {
            InitializeComponent();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM Dailyinovice", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            if (dt4.Rows.Count == 1)
            {
                string totalamout = dt4.Rows[0][0].ToString();
                label1.Text = totalamout;
            }
            sqaa = new SqlDataAdapter("SELECT * FROM Dailyinovice", con);
            dt4 = new DataTable();
            sqaa.Fill(dt4);
            dataGridView1.DataSource = dt4;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
