﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class credit_payment : Form
    {
        public credit_payment()
        {
            InitializeComponent();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaa1 = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
            DataTable dt41 = new DataTable();
            sqaa1.Fill(dt41);
            string totalamout1 = dt41.Rows[0][0].ToString();
            totalamountlabel.Text = totalamout1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaaa = new SqlDataAdapter("SELECT * FROM workers where employ_number='" + employnumberbox.Text + "'", con);
            DataTable dt5 = new DataTable();
            sqaaa.Fill(dt5);
            if (dt5.Rows.Count == 1)//IF THE EMPLOYEE IS ON THE LIST
            {
                if (!string.IsNullOrEmpty(customeridbox.Text))//IF CUSTOMER ID BOX FILLD
                {

                    SqlDataAdapter sqanew = new SqlDataAdapter("SELECT * FROM customers where id='" + customeridbox.Text + "'", con);
                    DataTable dt55 = new DataTable();
                    sqanew.Fill(dt55);
                    if (dt55.Rows.Count == 1)//If The customer box filld and he is on the list
                    {
                        SqlDataAdapter sqaa = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
                        DataTable dt4 = new DataTable();
                        sqaa.Fill(dt4);
                        string totalamout = dt4.Rows[0][0].ToString();
                        SqlDataAdapter sqa = new SqlDataAdapter("INSERT INTO Dailyinovice (date,price,payment_type) VALUES (getdate(),'" + totalamout + "','credit')", con);
                        sqa.SelectCommand.ExecuteNonQuery();
                        SqlDataAdapter sqa1 = new SqlDataAdapter("INSERT INTO Total_inovice (date,price,employee_number,payment_type,credit_inovice) VALUES(getdate(),'" + totalamout + "','" + employnumberbox.Text + "','credit','"+creditinoivcebox.Text+"')", con);
                        sqa1.SelectCommand.ExecuteNonQuery();
                        SqlDataAdapter aqd = new SqlDataAdapter("DELETE FROM TemporyRecipe", con);
                        aqd.SelectCommand.ExecuteNonQuery();
                        int pointsforcustomer = Int32.Parse(totalamout);
                        pointsforcustomer = pointsforcustomer / 10;
                        SqlDataAdapter sqanew1 = new SqlDataAdapter("SELECT points FROM customers where id='" + customeridbox.Text + "'", con);
                        DataTable dt551 = new DataTable();
                        sqanew1.Fill(dt551);
                        int currentpoints = Int32.Parse(dt551.Rows[0][0].ToString());
                        pointsforcustomer = pointsforcustomer + currentpoints;//add points to the customer
                        SqlDataAdapter sda = new SqlDataAdapter("UPDATE customers SET points='" + pointsforcustomer + "' WHERE id='" + customeridbox.Text + "'", con);
                        sda.SelectCommand.ExecuteNonQuery();
                        MessageBox.Show("Payed!");
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("customer is not on the list");
                    }
                }
                else//IF CUSTOMER ID BOX IS NOT FILL
                {
                    SqlDataAdapter sqaa1 = new SqlDataAdapter("SELECT sum(price) FROM TemporyRecipe", con);
                    DataTable dt41 = new DataTable();
                    sqaa1.Fill(dt41);
                    string totalamout1 = dt41.Rows[0][0].ToString();
                    SqlDataAdapter sqa111 = new SqlDataAdapter("INSERT INTO Dailyinovice (date,price,payment_type) VALUES (getdate(),'" + totalamout1 + "','credit')", con);
                    sqa111.SelectCommand.ExecuteNonQuery();
                    SqlDataAdapter sqa11 = new SqlDataAdapter("INSERT INTO Total_inovice (date,price,employee_number,payment_type,credit_inovice) VALUES(getdate(),'" + totalamout1 + "','" + employnumberbox.Text + "','credit','"+creditinoivcebox.Text+"')", con);
                    sqa11.SelectCommand.ExecuteNonQuery();
                    SqlDataAdapter aqd1 = new SqlDataAdapter("DELETE FROM TemporyRecipe", con);
                    aqd1.SelectCommand.ExecuteNonQuery();
                    MessageBox.Show("Payed!");
                    this.Hide();
                }
            }
            else//EMPLOYEE NOT ON THE LIST
            {
                MessageBox.Show("The Employee is not on the List");
            }

        }
    }
}
