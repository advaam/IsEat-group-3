﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class ViewEmployeesMeals : Form
    {
        public ViewEmployeesMeals()
        {
            InitializeComponent();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            SqlDataAdapter sqa = new SqlDataAdapter("SELECT * FROM workermeal", con);
            DataTable dt = new DataTable();
            sqa.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
