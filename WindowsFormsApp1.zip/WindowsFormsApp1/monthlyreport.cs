﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class monthlyreport : Form
    {
        public monthlyreport()
        {
            InitializeComponent();
            comboBox1.Items.Add("Sum_Total");
            comboBox1.Items.Add("All_inovice");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            if(comboBox1.SelectedItem.ToString()== "All_inovice")
            {
                SqlDataAdapter aqd = new SqlDataAdapter("SELECT * FROM CloseDay where CAST(day_date AS DATE) BETWEEN '" + startdatepicker.Value.ToString("yyyy-MM-dd") + "' AND '" + finishdatepicker.Value.ToString("yyyy-MM-dd") + "'", con);
                DataTable dt = new DataTable();
                aqd.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
            else
            {
                SqlDataAdapter aqd = new SqlDataAdapter("SELECT sum(total_amount) as [total amount],sum(cash_total) as [cash total],sum(credit_total) as [credit total] FROM CloseDay where CAST(day_date AS DATE) BETWEEN '" + startdatepicker.Value.ToString("yyyy-MM-dd") + "' AND '" + finishdatepicker.Value.ToString("yyyy-MM-dd") + "'", con);
                DataTable dt = new DataTable();
                aqd.Fill(dt);
                dataGridView1.DataSource = dt;
                con.Close();
            }
        }

        private void monthlyreport_Load(object sender, EventArgs e)
        {

        }
    }
}
