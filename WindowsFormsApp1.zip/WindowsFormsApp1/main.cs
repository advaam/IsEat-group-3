﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.userControls;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class main : Form
    {
        int panelWidth;
        bool isCollapsed;
        public main()
        {
            InitializeComponent();
            panelWidth = panelLeft.Width;
            isCollapsed = false;
            timer2.Start();
            this.Width = Int32.Parse(Screen.PrimaryScreen.Bounds.Width.ToString());
            this.Height = Int32.Parse(Screen.PrimaryScreen.Bounds.Height.ToString());
           
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(isCollapsed)
            {
                panelLeft.Width = panelLeft.Width + 10;
                if(panelLeft.Width>=panelWidth)
                {
                    timer1.Stop();
                    isCollapsed = false;
                    this.Refresh();

                }
            }
            else
            {
                panelLeft.Width = panelLeft.Width - 10;
                if(panelLeft.Width<=63)
                {
                    timer1.Stop();
                    isCollapsed = true;
                    this.Refresh();
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            timer1.Start();

        }
        private void AddControlsToPanel(Control c)
        {
            c.Dock = DockStyle.Fill;
            this.panelControls.Controls.Clear();
            this.panelControls.Controls.Add(c);

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            moveSidePanel(INVENTORY);
           
            premissions_login premission = new premissions_login();
            premission.ShowDialog();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from premission_login where premission=1 or premission=2", con);
            con.Close();
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                con.Open();
                SqlDataAdapter aSd = new SqlDataAdapter("DELETE premission_login", con);
                aSd.SelectCommand.ExecuteNonQuery();
                con.Close();
                UC_Inventory uch = new UC_Inventory();
                AddControlsToPanel(uch);

            }
            else
            {
                MessageBox.Show("no premission");
            }
            con.Open();
            SqlDataAdapter aLd = new SqlDataAdapter("DELETE premission_login", con);
            aLd.SelectCommand.ExecuteNonQuery();
            con.Close();

        }

        private void panelControls_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            moveSidePanel(button4);
            UC_customers uch = new UC_customers();
            AddControlsToPanel(uch);
        }

        private void button1_Click_2(object sender, EventArgs e)
        {
            Program.exit();
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            moveSidePanel(button3);
            premissions_login premission = new premissions_login();
            premission.ShowDialog();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from premission_login where premission=1", con);
            con.Close();
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                con.Open();
                SqlDataAdapter aSd = new SqlDataAdapter("DELETE premission_login", con);
                aSd.SelectCommand.ExecuteNonQuery();
                con.Close();
                UC_workers uch = new UC_workers();
                AddControlsToPanel(uch);

            }
            else
            {
                MessageBox.Show("no premission");
            }
            con.Open();
            SqlDataAdapter aLd = new SqlDataAdapter("DELETE premission_login", con);
            aLd.SelectCommand.ExecuteNonQuery();
            con.Close();

        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            moveSidePanel(button8);
            UC_clock k=new UC_clock();
            AddControlsToPanel(k);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            moveSidePanel(button6);
            premissions_login premission = new premissions_login();
            premission.ShowDialog();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from premission_login where premission=1", con);
            con.Close();
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                con.Open();
                SqlDataAdapter aSd = new SqlDataAdapter("DELETE premission_login", con);
                aSd.SelectCommand.ExecuteNonQuery();
                con.Close();
                UC_cashmanagment managment = new UC_cashmanagment();
                AddControlsToPanel(managment);

            }
            else
            {
                MessageBox.Show("no premission");
            }
            con.Open();
            SqlDataAdapter aLd = new SqlDataAdapter("DELETE premission_login", con);
            aLd.SelectCommand.ExecuteNonQuery();
            con.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            moveSidePanel(button2);
            UC_moneyBox cash_registar = new UC_moneyBox();
            AddControlsToPanel(cash_registar);
            
        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            moveSidePanel(button5);
            UC_reports rep = new UC_reports();
            AddControlsToPanel(rep);
            
        }

        private void timedatelabel_Click(object sender, EventArgs e)
        {
            
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timedatelabel.Text = DateTime.Now.ToLongTimeString();
            datetimelabel.Text = DateTime.Now.ToLongDateString();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            moveSidePanel(button9);
            OpenCloseDayPanel open = new OpenCloseDayPanel();
            AddControlsToPanel(open);
        }
        private void moveSidePanel(Control btn)
        {
            panelSide.Top = btn.Top;
            panelSide.Height = btn.Height;
        }

        private void button10_Click(object sender, EventArgs e)
        {
            
        }

        private void button10_Click_1(object sender, EventArgs e)
        {
            moveSidePanel(button9);
            
        }

    }
}
