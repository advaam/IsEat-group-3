﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class calculator : Form
    {
        static double x = 0;
        public calculator()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            x = 0;
            int agorot = 0;
            int HalfSakel = 0;
            int Shekel = 0;
            int TowShekel = 0;
            int FiveShekel = 0;
            int TenShekel = 0;
            int TwentyShekel = 0;
            int FiftyShekel = 0;
            int OneHShekel = 0;
            int TowHShekel = 0;
            if (!string.IsNullOrEmpty(calculatoragorotbox.Text))
            {
                agorot = Int32.Parse(calculatoragorotbox.Text);
            }
            if (!string.IsNullOrEmpty(calculatorHalfShekelbox.Text))
            {
                HalfSakel = Int32.Parse(calculatorHalfShekelbox.Text);
            }
            if (!string.IsNullOrEmpty(calculatorShekelbox.Text))
            {
                Shekel = Int32.Parse(calculatorShekelbox.Text);
            }
            if (!string.IsNullOrEmpty(calculatorTowShekelbox.Text))
            {
                TowShekel = Int32.Parse(calculatorTowShekelbox.Text);
            }
            if (!string.IsNullOrEmpty(calculatorFiveShekelbox.Text))
            {
                FiveShekel = Int32.Parse(calculatorFiveShekelbox.Text);
            }
            if (!string.IsNullOrEmpty(calculatorTenShekelbox.Text))
            {
                TenShekel = Int32.Parse(calculatorTenShekelbox.Text);
            }
            if (!string.IsNullOrEmpty(calculatorTwentyShekelbox.Text))
            {
                TwentyShekel = Int32.Parse(calculatorTwentyShekelbox.Text);
            }
            if (!string.IsNullOrEmpty(calculatorFiftyShekelbox.Text))
            {
                FiftyShekel = Int32.Parse(calculatorFiftyShekelbox.Text);
            }
            if (!string.IsNullOrEmpty(calculatorOneHShekelbox.Text))
            {
                OneHShekel = Int32.Parse(calculatorOneHShekelbox.Text);
            }
            if (!string.IsNullOrEmpty(calculatorTowHShekelbox.Text))
            {
                TowHShekel = Int32.Parse(calculatorTowHShekelbox.Text);
            }
            x = x + 0.1 * agorot + 0.5 * HalfSakel + Shekel + 2 * TowShekel + 5 * FiveShekel + 10 * TenShekel + 20 * TwentyShekel + 50 * FiftyShekel + 100 * OneHShekel + 200 * TowHShekel;

            string total = x.ToString();
            label2.Text = total;
        }
    }
}
