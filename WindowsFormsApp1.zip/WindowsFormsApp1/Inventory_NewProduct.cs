﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class Inventory_NewProduct : Form
    {
        
        public Inventory_NewProduct()
        {
            InitializeComponent();
        }
        
        private void Inventory_Update_Load(object sender, EventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select product from stock where product='" + productNameBox.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                MessageBox.Show("The Product Is Already on the List");
            }
            else
            {
                
                SqlDataAdapter sqa = new SqlDataAdapter("INSERT INTO stock(product,quantity,cost) VALUES('" + productNameBox.Text + "','" + quantityBox.Text + "','" + costBox.Text + "')", con);
                sqa.SelectCommand.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("add");
                this.Hide();
            }
        }
    }
}
