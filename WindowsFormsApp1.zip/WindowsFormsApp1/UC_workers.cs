﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1.userControls
{
    public partial class UC_workers : UserControl
    {
        public UC_workers()
        {
            InitializeComponent();
        }

        private void newProductButton_Click(object sender, EventArgs e)
        {
            new_worker1 worker = new new_worker1();
            worker.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            delte_worker delete = new delte_worker();
            delete.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            update_premission update = new update_premission();
            update.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            workersview view = new workersview();
            view.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ViewEmployeesMeals newview = new ViewEmployeesMeals();
            newview.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CalculatingAverageInovice CALC = new CalculatingAverageInovice();
            CALC.Show();
        }
    }
}
