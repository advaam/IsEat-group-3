﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Reflection;

namespace WindowsFormsApp1
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new login());
        }

        public static void exit()
        {
            DialogResult res = MessageBox.Show("Are you sure you want to exit?", "Exit?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                Environment.Exit(0);
            }
        }

        public static void controlclick(Control e)
        {

        }

        public static string connectionstrings(string dbname)
        {
            try
            {
                // Init app path
                string dbconnectionstring;

                // Patch for TESTING purpose!! #IMPORTANT: change the directory path
                if (Application.ExecutablePath.Contains("test"))
                {
                    dbconnectionstring = "D:\\Users\\Moran\\Desktop\\grop3\\grop3\\ragv\\WindowsFormsApp1\\WindowsFormsApp1\\";
                    //SSPI
                    dbconnectionstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + dbconnectionstring + dbname + ";Integrated Security=True;Connect Timeout=30";
                }
                else
                {
                    dbconnectionstring = System.IO.Path.GetDirectoryName(Application.ExecutablePath);

                    for (int i = 0; i <= 8; i++)
                    {
                        dbconnectionstring = dbconnectionstring.Remove(dbconnectionstring.Length - 1);
                    }

                    dbconnectionstring = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=" + dbconnectionstring + dbname + ";Integrated Security=True;Connect Timeout=30";
                }

                return dbconnectionstring;

            }
            catch (Exception e)
            {
                
                MessageBox.Show("Error accorred", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Environment.Exit(0);
                return "";
            }
        }
        
    }
}
