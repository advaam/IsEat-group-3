﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class premissions_login : Form
    {
        public premissions_login()
        {
            InitializeComponent();
        }
                

        private void button1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from workers where employ_number ='" + employnumberloginbox.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                string premission=dt.Rows[0]["premission"].ToString();
                SqlDataAdapter sda = new SqlDataAdapter("INSERT INTO premission_login (employ_number,premission) VALUES('" + employnumberloginbox.Text + "','"+premission+"')", con);
                sda.SelectCommand.ExecuteNonQuery();
                con.Close();
                this.Hide();
            }
            else
            {
                this.Hide();
            }
        }

        private void premissions_login_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from workers where employ_number ='" + employnumberloginbox.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                string premission = dt.Rows[0]["premission"].ToString();
                SqlDataAdapter sda = new SqlDataAdapter("INSERT INTO premission_login (employ_number,premission) VALUES('" + employnumberloginbox.Text + "','" + premission + "')", con);
                sda.SelectCommand.ExecuteNonQuery();
                con.Close();
                this.Hide();
            }
            else
            {
                this.Hide();
            }
        }

        private void button2_Click_2(object sender, EventArgs e)
        {

            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from workers where employ_number ='" + employnumberloginbox.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                string premission = dt.Rows[0]["premission"].ToString();
                SqlDataAdapter sda = new SqlDataAdapter("INSERT INTO premission_login (employ_number,premission) VALUES('" + employnumberloginbox.Text + "','" + premission + "')", con);
                sda.SelectCommand.ExecuteNonQuery();
                con.Close();
                this.Hide();
            }
            else
            {
                this.Hide();
            }
        }

        private void employnumberloginbox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
