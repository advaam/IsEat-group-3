﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1.userControls
{
    public partial class clocl_exit : Form
    {
        public clocl_exit()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from workers where id ='" + EXITCLOCKIDBOX.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                aqd = new SqlDataAdapter("select * from workers_hours where id ='" + EXITCLOCKIDBOX.Text + "' and enter is not null and exit_time is null", con);
                DataTable rs = new DataTable();
                aqd.Fill(rs);
                if(rs.Rows.Count==1)
                {
                    SqlDataAdapter sda = new SqlDataAdapter("UPDATE workers_hours SET exit_time = getdate() WHERE id='" + EXITCLOCKIDBOX.Text + "' AND enter IS NOT NULL AND exit_time IS NULL", con);
                    sda.SelectCommand.ExecuteNonQuery();
                    MessageBox.Show("out!");
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Enter the Clock First");
                }
                
            }
            else
            {
                MessageBox.Show("id is not on the list");
            }
        }
    }
}
