﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1.userControls
{
    public partial class adding_customer1 : Form
    {
        public adding_customer1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter aqd = new SqlDataAdapter("select * from customers where id ='" + IDCUSTOMERBOX.Text + "'", con);
            DataTable dt = new DataTable();
            aqd.Fill(dt);
            if (dt.Rows.Count == 1)
            {
                MessageBox.Show("Customer is Already on the List");
            }
            else
            {
                SqlDataAdapter sda = new SqlDataAdapter("INSERT INTO customers (id,first_name,last_name,phone) VALUES('" + IDCUSTOMERBOX.Text + "','" + FIRSTNAMECUSTOMERBOX.Text + "','" + LASTNAMECUSTOMERBOX.Text + "','" + PHONENUMBERCUSTOMERBOX.Text + "')", con);
                sda.SelectCommand.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("add");
                this.Dispose();
            }
            
        }
    }
}
