﻿namespace WindowsFormsApp1
{
    partial class calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(calculator));
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.calculatorTowHShekelbox = new System.Windows.Forms.TextBox();
            this.calculatorOneHShekelbox = new System.Windows.Forms.TextBox();
            this.calculatorFiftyShekelbox = new System.Windows.Forms.TextBox();
            this.calculatorTwentyShekelbox = new System.Windows.Forms.TextBox();
            this.calculatorTenShekelbox = new System.Windows.Forms.TextBox();
            this.calculatorFiveShekelbox = new System.Windows.Forms.TextBox();
            this.calculatorTowShekelbox = new System.Windows.Forms.TextBox();
            this.calculatorShekelbox = new System.Windows.Forms.TextBox();
            this.calculatorHalfShekelbox = new System.Windows.Forms.TextBox();
            this.calculatoragorotbox = new System.Windows.Forms.TextBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(280, 506);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(151, 53);
            this.label3.TabIndex = 82;
            this.label3.Text = "Total :";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(368, 575);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(190, 39);
            this.button1.TabIndex = 81;
            this.button1.Text = "Calculator";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(448, 516);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 39);
            this.label2.TabIndex = 80;
            this.label2.Text = "00";
            // 
            // calculatorTowHShekelbox
            // 
            this.calculatorTowHShekelbox.Location = new System.Drawing.Point(684, 378);
            this.calculatorTowHShekelbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.calculatorTowHShekelbox.Name = "calculatorTowHShekelbox";
            this.calculatorTowHShekelbox.Size = new System.Drawing.Size(157, 26);
            this.calculatorTowHShekelbox.TabIndex = 79;
            // 
            // calculatorOneHShekelbox
            // 
            this.calculatorOneHShekelbox.Location = new System.Drawing.Point(684, 306);
            this.calculatorOneHShekelbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.calculatorOneHShekelbox.Name = "calculatorOneHShekelbox";
            this.calculatorOneHShekelbox.Size = new System.Drawing.Size(157, 26);
            this.calculatorOneHShekelbox.TabIndex = 78;
            // 
            // calculatorFiftyShekelbox
            // 
            this.calculatorFiftyShekelbox.Location = new System.Drawing.Point(684, 239);
            this.calculatorFiftyShekelbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.calculatorFiftyShekelbox.Name = "calculatorFiftyShekelbox";
            this.calculatorFiftyShekelbox.Size = new System.Drawing.Size(157, 26);
            this.calculatorFiftyShekelbox.TabIndex = 77;
            // 
            // calculatorTwentyShekelbox
            // 
            this.calculatorTwentyShekelbox.Location = new System.Drawing.Point(684, 171);
            this.calculatorTwentyShekelbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.calculatorTwentyShekelbox.Name = "calculatorTwentyShekelbox";
            this.calculatorTwentyShekelbox.Size = new System.Drawing.Size(164, 26);
            this.calculatorTwentyShekelbox.TabIndex = 76;
            // 
            // calculatorTenShekelbox
            // 
            this.calculatorTenShekelbox.Location = new System.Drawing.Point(677, 99);
            this.calculatorTenShekelbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.calculatorTenShekelbox.Name = "calculatorTenShekelbox";
            this.calculatorTenShekelbox.Size = new System.Drawing.Size(164, 26);
            this.calculatorTenShekelbox.TabIndex = 75;
            // 
            // calculatorFiveShekelbox
            // 
            this.calculatorFiveShekelbox.Location = new System.Drawing.Point(199, 378);
            this.calculatorFiveShekelbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.calculatorFiveShekelbox.Name = "calculatorFiveShekelbox";
            this.calculatorFiveShekelbox.Size = new System.Drawing.Size(162, 26);
            this.calculatorFiveShekelbox.TabIndex = 74;
            // 
            // calculatorTowShekelbox
            // 
            this.calculatorTowShekelbox.Location = new System.Drawing.Point(199, 306);
            this.calculatorTowShekelbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.calculatorTowShekelbox.Name = "calculatorTowShekelbox";
            this.calculatorTowShekelbox.Size = new System.Drawing.Size(160, 26);
            this.calculatorTowShekelbox.TabIndex = 73;
            // 
            // calculatorShekelbox
            // 
            this.calculatorShekelbox.Location = new System.Drawing.Point(199, 239);
            this.calculatorShekelbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.calculatorShekelbox.Name = "calculatorShekelbox";
            this.calculatorShekelbox.Size = new System.Drawing.Size(160, 26);
            this.calculatorShekelbox.TabIndex = 72;
            // 
            // calculatorHalfShekelbox
            // 
            this.calculatorHalfShekelbox.Location = new System.Drawing.Point(199, 171);
            this.calculatorHalfShekelbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.calculatorHalfShekelbox.Name = "calculatorHalfShekelbox";
            this.calculatorHalfShekelbox.Size = new System.Drawing.Size(160, 26);
            this.calculatorHalfShekelbox.TabIndex = 71;
            // 
            // calculatoragorotbox
            // 
            this.calculatoragorotbox.Location = new System.Drawing.Point(199, 99);
            this.calculatoragorotbox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.calculatoragorotbox.Name = "calculatoragorotbox";
            this.calculatoragorotbox.Size = new System.Drawing.Size(160, 26);
            this.calculatoragorotbox.TabIndex = 70;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(524, 154);
            this.pictureBox8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(112, 62);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 68;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(524, 84);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(112, 62);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 67;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackColor = System.Drawing.Color.White;
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(54, 294);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(112, 62);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 66;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.Color.White;
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(54, 154);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(112, 62);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 65;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(524, 224);
            this.pictureBox9.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(112, 62);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 64;
            this.pictureBox9.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(524, 364);
            this.pictureBox10.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(112, 62);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 63;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(524, 294);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(112, 62);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 62;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(54, 364);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(112, 62);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 61;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.White;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(54, 224);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(112, 62);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 60;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(54, 84);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(112, 62);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 69;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(343, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(252, 53);
            this.label1.TabIndex = 59;
            this.label1.Text = "Calculator";
            // 
            // calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SlateGray;
            this.ClientSize = new System.Drawing.Size(958, 626);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.calculatorTowHShekelbox);
            this.Controls.Add(this.calculatorOneHShekelbox);
            this.Controls.Add(this.calculatorFiftyShekelbox);
            this.Controls.Add(this.calculatorTwentyShekelbox);
            this.Controls.Add(this.calculatorTenShekelbox);
            this.Controls.Add(this.calculatorFiveShekelbox);
            this.Controls.Add(this.calculatorTowShekelbox);
            this.Controls.Add(this.calculatorShekelbox);
            this.Controls.Add(this.calculatorHalfShekelbox);
            this.Controls.Add(this.calculatoragorotbox);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "calculator";
            this.Text = "calculator";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox calculatorTowHShekelbox;
        private System.Windows.Forms.TextBox calculatorOneHShekelbox;
        private System.Windows.Forms.TextBox calculatorFiftyShekelbox;
        private System.Windows.Forms.TextBox calculatorTwentyShekelbox;
        private System.Windows.Forms.TextBox calculatorTenShekelbox;
        private System.Windows.Forms.TextBox calculatorFiveShekelbox;
        private System.Windows.Forms.TextBox calculatorTowShekelbox;
        private System.Windows.Forms.TextBox calculatorShekelbox;
        private System.Windows.Forms.TextBox calculatorHalfShekelbox;
        private System.Windows.Forms.TextBox calculatoragorotbox;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}