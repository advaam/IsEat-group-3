﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApp1
{
    public partial class recipetsreport : Form
    {
        public recipetsreport()
        {
            InitializeComponent();
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT * FROM total_inovice", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            dataGridView1.DataSource = dt4;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string con1 = Program.connectionstrings("LoginDB.mdf");
            SqlConnection con = new SqlConnection(@con1);
            con.Open();
            SqlDataAdapter sqaa = new SqlDataAdapter("SELECT * FROM total_inovice where inovice_number='" + reciptenumberbox.Text + "'", con);
            DataTable dt4 = new DataTable();
            sqaa.Fill(dt4);
            if(dt4.Rows.Count==1)
            {
                dataGridView1.DataSource = dt4;
            }
            else
            {
                MessageBox.Show("inovice number is not on the list");
            }
        }
    }
}
