﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1.userControls.forms.customers_forms
{
    public partial class customers_view : Form
    {
        public customers_view()
        {
            InitializeComponent();
        }
    }
}
