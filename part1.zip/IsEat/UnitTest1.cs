﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using WindowsFormsApp1;

namespace IsEat
{
    [TestClass]
    public class projecttest
    {
        [TestMethod]
        public void testltest()
        {
            var test = new main();
        }
    }
}
